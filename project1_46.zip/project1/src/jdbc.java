import java.sql.*;

public class jdbc
{
    public static void main(String[] args)
    {
        System.out.println("Hello World");
    }
}
